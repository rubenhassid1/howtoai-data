# How to AI — Newsletter Archive

Posts from the [How to AI](https://ruben.substack.com) newsletter by Ruben Hassid.

## What's inside
- [10] newsletter posts in Markdown format
- Each post includes frontmatter with title, date, subtitle, and original URL

## Usage
These files work great with AI tools. Drop them into Claude, ChatGPT, or your favorite LLM for analysis, search, or reference.

## MCP Access
Point your MCP client to this directory to give your AI assistant access to the full archive.
